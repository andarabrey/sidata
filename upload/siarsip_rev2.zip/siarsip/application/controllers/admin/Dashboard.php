<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	function __construct(){
		parent::__construct();
		$password = $this->session->userdata('pass');
		if($this->session->userdata('status') != "logged"){
			redirect('Login');
		}
		$this->load->model('M_Home');

	}

	public function index(){

		$th_masuk = $this->M_Home->getYear();
		$data=array('mainheader'		=> 'template/mainheader',
								'mainpage'			=> 'admin/template/mainpage',
								'navbar'				=> 'admin/template/navbar',
								'th_masuk' => $th_masuk,
								
								);

		$this->load->view('index-dashboard',$data);
	}

	public function profil(){
		$struktur = $this->M_Home->struktur();
		$data=array('mainheader'		=> 'template/mainheader',
								'mainpage'			=> 'admin/profil',
								'navbar'				=> 'admin/template/navbar',
								'struktur' => $struktur
								);

		$this->load->view('index-dashboard',$data);
	}

	function update_struktur($id){
		$data=array(			'kepsek'			=> $this->input->post('kepsek'),
								'wakil_kurikulum'			=> $this->input->post('wakil'),
								'bk'			=> $this->input->post('bk'),
								'staff'			=> $this->input->post('staff'),
								'guru_bidang'			=> $this->input->post('guru'),
								'pustakawan'			=> $this->input->post('pustakawan'),
								);

		$this->M_Home->update_struktur($id,$data);
		redirect('admin/dashboard/profil');
	}


	public function showchart()
	{
		$year1 = $this->input->post('yearOne');
		$year2 = $this->input->post('yearTwo');

		$earning1 = $this->M_Home->getEarning($year1);
		$earning2 = $this->M_Home->getEarning($year2);	

		//print_r($label);
		$Data['th_masuk'] = $this->M_Home->getYear();
		$Data['result1'] = json_encode($earning1);
		$Data['result2'] = json_encode($earning2);
		$Data['one'] = $year1;
		$Data['two'] = $year2;
		$Data['mainheader'] ='template/mainheader';
		$Data['mainpage'] = 'admin/template/chart';
		$Data['navbar'] = 'admin/template/navbar';

		$this->load->view('index-dashboard', $Data);
		//print_r($this->m_datachart->getMonth());
		// print_r($this->m_datachart->getEarning($year1));
		// echo " spasi ";
		//print_r($this->m_datachart->getEarning($year2));

	}

}