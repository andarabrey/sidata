<?php if(!defined('BASEPATH')) exit('Hacking Attempt : Keluar dari sistem..!!');

class M_Home extends CI_Model
{
    public function getYear(){
        // $this->db->select('year');
        // $this->db->group_by('year');
        // $query = $this->db->get('earnings');
        $query = $this->db->query("SELECT DISTINCT th_masuk FROM tb_ketr ORDER BY th_masuk ASC");
        return $query->result();
    }

    public function getYear2(){
        // $this->db->select('year');
        // $this->db->group_by('year');
        // $query = $this->db->get('earnings');
        $query = $this->db->query("SELECT th_masuk FROM tb_ketr ORDER BY th_masuk ASC");
        return $query->num_rows();
    }

    public function getEarning($year){
    	// $this->db->select("total");
    	// $this->db->order_by("STR_TO_DATE(month, '%m')");
    	// $query = $this->db->get_where("earnings", array("year" => $year));
    	$query = $this->db->query("SELECT * FROM tb_ketr WHERE th_masuk = '$year'");
    	return $query->num_rows();
    }

    public function struktur(){
        // $this->db->select('year');
        // $this->db->group_by('year');
        // $query = $this->db->get('earnings');
        $query = $this->db->query("SELECT * FROM tb_struktur");
        return $query->result_array();
    }


    function update_struktur($id,$data){
		$this->db->where('id', $id);
		return $this->db->update("tb_struktur",$data);
	}
}