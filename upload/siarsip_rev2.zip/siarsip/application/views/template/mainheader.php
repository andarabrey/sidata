<header class="main-header">
    <!-- Logo -->
    <a href="<?php echo base_url(); ?>admin/Dashboard" class="logo" style="background-color:#007f43">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>SI</b>ARSIP SISWA</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg">SI<b> ARSIP SISWA</b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top" style="background-color:#008D4C">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <span class=" fa fa-upload"></span>
              <span class="hidden-xs">Log Out</span>
            </a>


            <ul class="dropdown-menu" style="width: auto; min-width: 0">
              <!-- User image -->
              <!-- Menu Body -->
              <!-- Menu Footer-->
              <li class="user-footer" >
                <div class="pull-right">
                  <a href="<?php echo base_url(); ?>Login/logout" class="btn btn-danger btn-flat">Click !! to go</i></a>
                </div>
              </li>
            </ul>

          </li>
          <!-- Control Sidebar Toggle Button -->
          
        </ul>
      </div>
    </nav>
  </header>