
<div style="background-color:white;">
<img class="img-responsive center-block" style="max-height: 100px;padding:10px;" src="<?php echo base_url();?>assets/img/logo.png" alt="">
<p style="text-align:center"><b>MTs Darussalam Kota Bengkulu</b></p>

</div>


<ul class="sidebar-menu">
  <li class="header">MAIN NAVIGATION</li>


<li class="<?php if($this->uri->segment(2) == ""){echo "active";} ?> treeview">
    <a href="<?php echo base_url(); ?>admin/Dashboard">
    <i class="fa fa-folder-open"></i> <span>Home</span>
    </a>
  </li>

  <li class="<?php if($this->uri->segment(2) == ""){echo "active";} ?> treeview">
    <a href="<?php echo base_url(); ?>admin/user">
    <i class="fa fa-folder-open"></i> <span>Menejemen Admin</span>
    </a>
  </li>

  <li class="<?php if($this->uri->segment(2) == ""){echo "active";} ?> treeview">
    <a href="<?php echo base_url(); ?>admin/siswa">
    <i class="fa fa-book"></i> <span>Menejemen Siswa</span>
    </a>
  </li>

    <li class="<?php if($this->uri->segment(2) == ""){echo "active";} ?> treeview">
    <a href="<?php echo base_url(); ?>admin/Dashboard/profil">
    <i class="fa fa-book"></i> <span>Profil Sekolah</span>
    </a>
  </li>
  <br>
</ul>

